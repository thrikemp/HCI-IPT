# 🏥 Clinic Visiting System

A complete clinic management system built with **Laravel 10** and **SQLite** (zero external database setup required).

---

## ✅ Prerequisites

Before you start, install these on your machine:

| Tool | Version | Download |
|------|---------|----------|
| PHP | 8.1 or higher | https://www.php.net/downloads |
| Composer | Latest | https://getcomposer.org |
| Git (optional) | Any | https://git-scm.com |

> **Windows users**: The easiest way to get PHP + Composer is via [Laravel Herd](https://herd.laravel.com) (free) or [XAMPP](https://www.apachefriends.org).

---

## 🚀 Setup (One-Time)

### Option A – Automated Script (Recommended)

**macOS / Linux:**
```bash
cd clinic-system
chmod +x setup.sh
./setup.sh
```

**Windows (Command Prompt or PowerShell):**
```bat
cd clinic-system
setup.bat
```

---

### Option B – Manual Steps

Open a terminal in VS Code (`Ctrl+`` ` or Terminal → New Terminal) and run these one by one:

```bash
# 1. Install PHP dependencies
composer install

# 2. Create the environment file
cp .env.example .env        # macOS/Linux
copy .env.example .env      # Windows

# 3. Generate the app encryption key
php artisan key:generate

# 4. Create the SQLite database file
mkdir -p database
touch database/clinic.sqlite      # macOS/Linux
type nul > database\clinic.sqlite # Windows

# 5. Run all migrations and seed demo data
php artisan migrate --seed

# 6. Start the development server
php artisan serve
```

---

## 🌐 Open the App

Once the server is running:

```
http://localhost:8000
```

### Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@clinic.local | password |
| Receptionist | receptionist@clinic.local | password |
| Doctor | rreyes@clinic.local | password |

---

## 📁 Project Structure

```
clinic-system/
├── app/
│   ├── Http/
│   │   ├── Controllers/         # One controller per feature
│   │   │   ├── AuthController.php
│   │   │   ├── DashboardController.php
│   │   │   ├── PatientController.php
│   │   │   ├── AppointmentController.php
│   │   │   ├── DoctorController.php
│   │   │   └── QueueController.php
│   │   └── Requests/            # Form validation classes
│   ├── Models/                  # Eloquent models
│   │   ├── User.php
│   │   ├── Doctor.php
│   │   ├── Patient.php
│   │   ├── Appointment.php
│   │   └── VisitQueue.php
│   └── Services/                # Business logic layer
│       ├── AppointmentService.php
│       └── PatientService.php
├── database/
│   ├── migrations/              # DB schema (runs in order)
│   └── seeders/                 # Demo data
├── resources/views/             # Blade templates
│   ├── layouts/app.blade.php    # Master layout
│   ├── auth/
│   ├── dashboard/
│   ├── patients/
│   ├── appointments/
│   ├── doctors/
│   └── queue/
├── routes/web.php               # All web routes
├── config/                      # App, DB, auth, session config
├── setup.sh                     # Linux/macOS one-shot setup
└── setup.bat                    # Windows one-shot setup
```

---

## ⚙️ Features

| Feature | Description |
|---------|-------------|
| **Dashboard** | Today's appointments, live queue status, stats |
| **Patient Management** | Register, search, view history, edit patients |
| **Appointment Booking** | Schedule with doctor + date/time selection |
| **Check-in & Queue** | Check in patients, auto queue numbering |
| **Queue Management** | Call next, mark in-progress, mark done, skip |
| **Doctor Management** | Add doctors, toggle availability |
| **Auth** | Login/logout with role-based user system |

---

## 🔄 Useful Commands

```bash
# Re-seed fresh demo data
php artisan migrate:fresh --seed

# View all registered routes
php artisan route:list

# Clear all caches
php artisan optimize:clear
```

---

## 🗄️ Switching to MySQL (Optional)

Edit `.env`:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=clinic_db
DB_USERNAME=root
DB_PASSWORD=your_password
```

Then run `php artisan migrate --seed`.
