<?php

namespace Database\Seeders;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use Illuminate\Database\Seeder;

class AppointmentSeeder extends Seeder
{
    public function run(): void
    {
        $patients = Patient::all();
        $doctors  = Doctor::all();

        if ($patients->isEmpty() || $doctors->isEmpty()) return;

        $reasons = ['General check-up', 'Fever and headache', 'Follow-up consultation', 'Annual physical', 'Cough and colds'];

        // Today's appointments
        foreach ($patients->take(3) as $i => $patient) {
            Appointment::create([
                'patient_id'       => $patient->id,
                'doctor_id'        => $doctors[$i % $doctors->count()]->id,
                'appointment_date' => now()->setTime(8 + $i * 2, 0),
                'status'           => 'scheduled',
                'reason'           => $reasons[$i],
            ]);
        }

        // Upcoming
        foreach ($patients->skip(3) as $i => $patient) {
            Appointment::create([
                'patient_id'       => $patient->id,
                'doctor_id'        => $doctors[$i % $doctors->count()]->id,
                'appointment_date' => now()->addDays($i + 1)->setTime(9, 0),
                'status'           => 'scheduled',
                'reason'           => $reasons[($i + 3) % count($reasons)],
            ]);
        }
    }
}
