<?php

namespace Database\Seeders;

use App\Models\Patient;
use Illuminate\Database\Seeder;

class PatientSeeder extends Seeder
{
    public function run(): void
    {
        $patients = [
            ['first_name' => 'Juan',    'last_name' => 'dela Cruz',  'phone' => '09171234567', 'dob' => '1990-04-15', 'gender' => 'male'],
            ['first_name' => 'Maria',   'last_name' => 'Reyes',      'phone' => '09289876543', 'dob' => '1985-08-22', 'gender' => 'female'],
            ['first_name' => 'Jose',    'last_name' => 'Santos',     'phone' => '09351112233', 'dob' => '1978-01-30', 'gender' => 'male'],
            ['first_name' => 'Ana',     'last_name' => 'Garcia',     'phone' => '09172223344', 'dob' => '2005-06-10', 'gender' => 'female'],
            ['first_name' => 'Pedro',   'last_name' => 'Villanueva', 'phone' => '09284445566', 'dob' => '1965-11-05', 'gender' => 'male'],
            ['first_name' => 'Rosa',    'last_name' => 'Flores',     'phone' => '09356667788', 'dob' => '1995-03-18', 'gender' => 'female'],
        ];

        foreach ($patients as $p) {
            Patient::create([
                'first_name'    => $p['first_name'],
                'last_name'     => $p['last_name'],
                'phone'         => $p['phone'],
                'date_of_birth' => $p['dob'],
                'gender'        => $p['gender'],
                'email'         => strtolower($p['first_name']) . '.' . strtolower($p['last_name']) . '@example.com',
            ]);
        }
    }
}
