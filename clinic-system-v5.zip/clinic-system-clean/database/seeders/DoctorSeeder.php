<?php

namespace Database\Seeders;

use App\Models\Doctor;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DoctorSeeder extends Seeder
{
    public function run(): void
    {
        $doctors = [
            ['name' => 'Dr. Rodrigo Reyes',  'email' => 'rreyes@clinic.local',   'spec' => 'General Medicine',  'lic' => 'LIC-2024-001'],
            ['name' => 'Dr. Liza Tan',        'email' => 'ltan@clinic.local',     'spec' => 'Pediatrics',        'lic' => 'LIC-2024-002'],
            ['name' => 'Dr. Carlos Mendoza',  'email' => 'cmendoza@clinic.local', 'spec' => 'Internal Medicine', 'lic' => 'LIC-2024-003'],
        ];

        foreach ($doctors as $d) {
            $user = User::create([
                'name'     => $d['name'],
                'email'    => $d['email'],
                'password' => Hash::make('password'),
                'role'     => 'doctor',
            ]);

            Doctor::create([
                'user_id'        => $user->id,
                'specialization' => $d['spec'],
                'license_number' => $d['lic'],
                'phone'          => '09' . rand(100000000, 999999999),
                'is_available'   => true,
            ]);
        }
    }
}
