<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        User::create([
            'name'     => 'Admin User',
            'email'    => 'admin@clinic.local',
            'password' => Hash::make('password'),
            'role'     => 'admin',
        ]);

        // Receptionist
        User::create([
            'name'     => 'Maria Santos',
            'email'    => 'receptionist@clinic.local',
            'password' => Hash::make('password'),
            'role'     => 'receptionist',
        ]);
    }
}
