<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('visit_queues', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appointment_id')->constrained()->onDelete('cascade');
            $table->integer('queue_number');
            $table->enum('status', ['waiting', 'in_progress', 'done', 'skipped'])->default('waiting');
            $table->time('check_in_time')->nullable();
            $table->time('called_time')->nullable();
            $table->time('done_time')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('visit_queues');
    }
};
