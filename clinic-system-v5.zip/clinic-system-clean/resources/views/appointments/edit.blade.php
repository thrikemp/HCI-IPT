@extends('layouts.app')
@section('title', 'Edit Appointment')
@section('page-title', 'Edit Appointment')

@section('content')
<div class="row">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header py-3"><i class="bi bi-pencil me-2 text-primary"></i>Edit Appointment #{{ $appointment->id }}</div>
            <div class="card-body">
                <form action="{{ route('appointments.update', $appointment) }}" method="POST">
                    @csrf @method('PUT')
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Patient *</label>
                        <select name="patient_id" class="form-select" required>
                            @foreach($patients as $p)
                                <option value="{{ $p->id }}" {{ $appointment->patient_id==$p->id?'selected':'' }}>
                                    {{ $p->full_name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Doctor *</label>
                        <select name="doctor_id" class="form-select" required>
                            @foreach($doctors as $d)
                                <option value="{{ $d->id }}" {{ $appointment->doctor_id==$d->id?'selected':'' }}>
                                    Dr. {{ $d->user->name }} – {{ $d->specialization }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Date & Time *</label>
                        <input type="datetime-local" name="appointment_date" class="form-control"
                               value="{{ old('appointment_date', $appointment->appointment_date->format('Y-m-d\TH:i')) }}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Reason *</label>
                        <input type="text" name="reason" class="form-control"
                               value="{{ old('reason', $appointment->reason) }}" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Notes</label>
                        <textarea name="notes" class="form-control" rows="3">{{ old('notes', $appointment->notes) }}</textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Save Changes</button>
                        <a href="{{ route('appointments.show', $appointment) }}" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
