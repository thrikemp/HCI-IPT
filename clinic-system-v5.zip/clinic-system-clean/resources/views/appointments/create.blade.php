@extends('layouts.app')
@section('title', 'New Appointment')
@section('page-title', 'Schedule Appointment')

@section('content')
<div class="row">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header py-3"><i class="bi bi-calendar-plus me-2 text-primary"></i>Appointment Details</div>
            <div class="card-body">
                <form action="{{ route('appointments.store') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Patient *</label>
                        <select name="patient_id" class="form-select @error('patient_id') is-invalid @enderror" required>
                            <option value="">Select patient</option>
                            @foreach($patients as $p)
                                <option value="{{ $p->id }}"
                                    {{ (old('patient_id', $selectedPatient?->id) == $p->id) ? 'selected' : '' }}>
                                    {{ $p->full_name }} ({{ $p->phone }})
                                </option>
                            @endforeach
                        </select>
                        @error('patient_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Doctor *</label>
                        <select name="doctor_id" class="form-select @error('doctor_id') is-invalid @enderror" required>
                            <option value="">Select doctor</option>
                            @foreach($doctors as $d)
                                <option value="{{ $d->id }}" {{ old('doctor_id')==$d->id?'selected':'' }}>
                                    Dr. {{ $d->user->name }} – {{ $d->specialization }}
                                </option>
                            @endforeach
                        </select>
                        @error('doctor_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Date & Time *</label>
                        <input type="datetime-local" name="appointment_date"
                               class="form-control @error('appointment_date') is-invalid @enderror"
                               value="{{ old('appointment_date') }}" required
                               min="{{ now()->addHour()->format('Y-m-d\TH:i') }}">
                        @error('appointment_date')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Reason for Visit *</label>
                        <input type="text" name="reason" class="form-control @error('reason') is-invalid @enderror"
                               value="{{ old('reason') }}" placeholder="e.g. General check-up, Fever, Follow-up…" required>
                        @error('reason')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Notes</label>
                        <textarea name="notes" class="form-control" rows="3"
                                  placeholder="Additional notes or instructions…">{{ old('notes') }}</textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-lg me-1"></i>Schedule Appointment
                        </button>
                        <a href="{{ route('appointments.index') }}" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
