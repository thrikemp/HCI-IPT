@extends('layouts.app')
@section('title', 'Appointments')
@section('page-title', 'Appointments')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <form class="d-flex gap-2" method="GET">
        <select name="status" class="form-select form-select-sm" style="width:160px">
            <option value="">All Status</option>
            @foreach(['scheduled','completed','cancelled','no_show'] as $s)
                <option value="{{ $s }}" {{ $status==$s?'selected':'' }}>{{ ucfirst(str_replace('_',' ',$s)) }}</option>
            @endforeach
        </select>
        <input type="date" name="date" class="form-control form-control-sm" value="{{ $date }}">
        <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-filter"></i> Filter</button>
        @if($status || $date)
            <a href="{{ route('appointments.index') }}" class="btn btn-sm btn-outline-danger"><i class="bi bi-x"></i></a>
        @endif
    </form>
    <a href="{{ route('appointments.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>New Appointment
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Date & Time</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Queue</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($appointments as $appt)
                <tr>
                    <td>
                        <a href="{{ route('patients.show', $appt->patient) }}" class="text-decoration-none fw-semibold">
                            {{ $appt->patient->full_name }}
                        </a>
                    </td>
                    <td>Dr. {{ $appt->doctor->user->name }}</td>
                    <td>{{ $appt->appointment_date->format('M d, Y') }}<br>
                        <small class="text-muted">{{ $appt->appointment_date->format('h:i A') }}</small>
                    </td>
                    <td><small>{{ Str::limit($appt->reason, 40) }}</small></td>
                    <td><span class="badge badge-{{ $appt->status }}">{{ ucfirst(str_replace('_',' ',$appt->status)) }}</span></td>
                    <td>
                        @if($appt->visitQueue)
                            <span class="fw-bold text-primary">#{{ $appt->visitQueue->queue_number }}</span>
                            <span class="badge badge-{{ $appt->visitQueue->status }} ms-1">{{ ucfirst($appt->visitQueue->status) }}</span>
                        @else
                            <span class="text-muted small">—</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('appointments.show', $appt) }}" class="btn btn-sm btn-outline-primary me-1">
                            <i class="bi bi-eye"></i>
                        </a>
                        @if($appt->isScheduled())
                            @if(!$appt->visitQueue)
                            <form action="{{ route('appointments.check-in', $appt) }}" method="POST" class="d-inline">
                                @csrf
                                <button class="btn btn-sm btn-outline-success me-1" title="Check-in">
                                    <i class="bi bi-door-open"></i>
                                </button>
                            </form>
                            @endif
                            <form action="{{ route('appointments.cancel', $appt) }}" method="POST" class="d-inline"
                                  onsubmit="return confirm('Cancel this appointment?')">
                                @csrf @method('PATCH')
                                <button class="btn btn-sm btn-outline-danger" title="Cancel">
                                    <i class="bi bi-x-circle"></i>
                                </button>
                            </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No appointments found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($appointments->hasPages())
    <div class="card-footer">{{ $appointments->withQueryString()->links() }}</div>
    @endif
</div>
@endsection
