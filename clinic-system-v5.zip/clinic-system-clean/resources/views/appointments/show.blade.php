@extends('layouts.app')
@section('title', 'Appointment')
@section('page-title', 'Appointment Detail')

@section('content')
<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-calendar-check me-2 text-primary"></i>Appointment #{{ $appointment->id }}</span>
                <span class="badge badge-{{ $appointment->status }} fs-6">{{ ucfirst(str_replace('_',' ',$appointment->status)) }}</span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="text-muted small">Patient</label>
                        <div class="fw-semibold">
                            <a href="{{ route('patients.show', $appointment->patient) }}">{{ $appointment->patient->full_name }}</a>
                        </div>
                        <div class="text-muted small">{{ $appointment->patient->phone }}</div>
                    </div>
                    <div class="col-md-6">
                        <label class="text-muted small">Doctor</label>
                        <div class="fw-semibold">Dr. {{ $appointment->doctor->user->name }}</div>
                        <div class="text-muted small">{{ $appointment->doctor->specialization }}</div>
                    </div>
                    <div class="col-md-6">
                        <label class="text-muted small">Appointment Date</label>
                        <div class="fw-semibold">{{ $appointment->appointment_date->format('F d, Y') }}</div>
                        <div class="text-muted small">{{ $appointment->appointment_date->format('h:i A') }}</div>
                    </div>
                    @if($appointment->visitQueue)
                    <div class="col-md-6">
                        <label class="text-muted small">Queue</label>
                        <div class="fw-semibold text-primary fs-4">#{{ $appointment->visitQueue->queue_number }}</div>
                        <span class="badge badge-{{ $appointment->visitQueue->status }}">{{ ucfirst($appointment->visitQueue->status) }}</span>
                    </div>
                    @endif
                    <div class="col-12">
                        <label class="text-muted small">Reason</label>
                        <div>{{ $appointment->reason }}</div>
                    </div>
                    @if($appointment->notes)
                    <div class="col-12">
                        <label class="text-muted small">Notes</label>
                        <div>{{ $appointment->notes }}</div>
                    </div>
                    @endif
                </div>

                <div class="mt-4 d-flex gap-2">
                    @if($appointment->isScheduled())
                        @if(!$appointment->visitQueue)
                        <form action="{{ route('appointments.check-in', $appointment) }}" method="POST">
                            @csrf
                            <button class="btn btn-success"><i class="bi bi-door-open me-1"></i>Check-in Patient</button>
                        </form>
                        @endif
                        <a href="{{ route('appointments.edit', $appointment) }}" class="btn btn-outline-primary">
                            <i class="bi bi-pencil me-1"></i>Edit
                        </a>
                        <form action="{{ route('appointments.cancel', $appointment) }}" method="POST"
                              onsubmit="return confirm('Cancel this appointment?')">
                            @csrf @method('PATCH')
                            <button class="btn btn-outline-danger"><i class="bi bi-x-circle me-1"></i>Cancel</button>
                        </form>
                    @endif
                    <a href="{{ route('appointments.index') }}" class="btn btn-outline-secondary">← Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
