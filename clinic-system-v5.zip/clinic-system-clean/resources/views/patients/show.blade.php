@extends('layouts.app')
@section('title', $patient->full_name)
@section('page-title', 'Patient Profile')

@section('content')
<div class="row g-3">
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-body text-center py-4">
                <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                     style="width:72px;height:72px;font-size:1.8rem;">
                    {{ strtoupper(substr($patient->first_name,0,1).substr($patient->last_name,0,1)) }}
                </div>
                <h5 class="fw-bold mb-0">{{ $patient->full_name }}</h5>
                <div class="text-muted small mb-3">{{ ucfirst($patient->gender) }} · {{ $patient->age }} years old</div>
                <a href="{{ route('patients.edit', $patient) }}" class="btn btn-sm btn-outline-primary me-1">
                    <i class="bi bi-pencil me-1"></i>Edit
                </a>
                <a href="{{ route('appointments.create', ['patient_id' => $patient->id]) }}" class="btn btn-sm btn-success">
                    <i class="bi bi-calendar-plus me-1"></i>Book
                </a>
            </div>
        </div>
        <div class="card">
            <div class="card-header py-3 fw-semibold"><i class="bi bi-info-circle me-2"></i>Details</div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><small class="text-muted d-block">Phone</small>{{ $patient->phone }}</li>
                @if($patient->email)
                <li class="list-group-item"><small class="text-muted d-block">Email</small>{{ $patient->email }}</li>
                @endif
                <li class="list-group-item"><small class="text-muted d-block">Date of Birth</small>{{ $patient->date_of_birth->format('M d, Y') }}</li>
                @if($patient->address)
                <li class="list-group-item"><small class="text-muted d-block">Address</small>{{ $patient->address }}</li>
                @endif
                @if($patient->emergency_contact_name)
                <li class="list-group-item">
                    <small class="text-muted d-block">Emergency Contact</small>
                    {{ $patient->emergency_contact_name }}<br>
                    <span class="text-muted small">{{ $patient->emergency_contact_phone }}</span>
                </li>
                @endif
            </ul>
        </div>
    </div>

    <div class="col-lg-8">
        @if($patient->medical_history)
        <div class="card mb-3">
            <div class="card-header py-3 fw-semibold"><i class="bi bi-clipboard2-pulse me-2 text-danger"></i>Medical History</div>
            <div class="card-body">{{ $patient->medical_history }}</div>
        </div>
        @endif

        <div class="card">
            <div class="card-header py-3 fw-semibold"><i class="bi bi-calendar-check me-2 text-primary"></i>Appointment History</div>
            <div class="card-body p-0">
                @forelse($patient->appointments as $appt)
                <div class="d-flex align-items-center px-3 py-2 border-bottom">
                    <div class="flex-grow-1">
                        <div class="fw-semibold small">{{ $appt->reason }}</div>
                        <div class="text-muted small">Dr. {{ $appt->doctor->user->name }} · {{ $appt->appointment_date->format('M d, Y h:i A') }}</div>
                        @if($appt->notes)<div class="text-muted small">{{ $appt->notes }}</div>@endif
                    </div>
                    <span class="badge badge-{{ $appt->status }}">{{ ucfirst(str_replace('_',' ',$appt->status)) }}</span>
                </div>
                @empty
                <div class="text-center py-4 text-muted">No appointment records.</div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
