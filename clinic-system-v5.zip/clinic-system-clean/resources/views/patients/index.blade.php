@extends('layouts.app')
@section('title', 'Patients')
@section('page-title', 'Patients')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <form class="d-flex gap-2" method="GET">
        <input type="text" name="search" class="form-control" placeholder="Search by name or phone…" value="{{ $search }}">
        <button class="btn btn-outline-secondary"><i class="bi bi-search"></i></button>
    </form>
    <a href="{{ route('patients.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Register Patient
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Appointments</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($patients as $patient)
                <tr>
                    <td class="text-muted">{{ $patient->id }}</td>
                    <td>
                        <div class="fw-semibold">{{ $patient->full_name }}</div>
                        <div class="text-muted small">{{ $patient->email }}</div>
                    </td>
                    <td>{{ $patient->phone }}</td>
                    <td>{{ ucfirst($patient->gender) }}</td>
                    <td>{{ $patient->age }}</td>
                    <td>{{ $patient->appointments_count ?? $patient->appointments()->count() }}</td>
                    <td>
                        <a href="{{ route('patients.show', $patient) }}" class="btn btn-sm btn-outline-primary me-1">
                            <i class="bi bi-eye"></i>
                        </a>
                        <a href="{{ route('patients.edit', $patient) }}" class="btn btn-sm btn-outline-secondary me-1">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="{{ route('appointments.create', ['patient_id' => $patient->id]) }}" class="btn btn-sm btn-outline-success">
                            <i class="bi bi-calendar-plus"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No patients found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($patients->hasPages())
    <div class="card-footer">{{ $patients->withQueryString()->links() }}</div>
    @endif
</div>
@endsection
