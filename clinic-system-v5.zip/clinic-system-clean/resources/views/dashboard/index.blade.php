@extends('layouts.app')
@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
{{-- Stats Row --}}
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg,#0f6fcd,#3b8fd9);">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="opacity-75 small mb-1">Total Patients</div>
                    <div class="fs-2 fw-bold">{{ $stats['total_patients'] }}</div>
                </div>
                <i class="bi bi-people fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg,#198754,#2aad72);">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="opacity-75 small mb-1">Doctors</div>
                    <div class="fs-2 fw-bold">{{ $stats['total_doctors'] }}</div>
                </div>
                <i class="bi bi-person-badge fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg,#fd7e14,#ffab5c);">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="opacity-75 small mb-1">Today's Appointments</div>
                    <div class="fs-2 fw-bold">{{ $stats['today_appointments'] }}</div>
                </div>
                <i class="bi bi-calendar-check fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card" style="background: linear-gradient(135deg,#6f42c1,#9c6fdf);">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="opacity-75 small mb-1">Waiting in Queue</div>
                    <div class="fs-2 fw-bold">{{ $stats['waiting_queue'] }}</div>
                </div>
                <i class="bi bi-list-ol fs-1 opacity-50"></i>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    {{-- Today's Appointments --}}
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center py-3">
                <span><i class="bi bi-calendar-day me-2 text-primary"></i>Today's Appointments</span>
                <a href="{{ route('appointments.create') }}" class="btn btn-sm btn-primary">
                    <i class="bi bi-plus me-1"></i>New
                </a>
            </div>
            <div class="card-body p-0">
                @forelse($todayAppointments as $appt)
                <div class="d-flex align-items-center px-3 py-2 border-bottom">
                    <div class="me-3">
                        @if($appt->visitQueue)
                            <div class="queue-number text-primary" style="font-size:1.4rem;">
                                #{{ $appt->visitQueue->queue_number }}
                            </div>
                        @else
                            <div class="text-muted" style="font-size:.75rem; width:40px; text-align:center;">No<br>queue</div>
                        @endif
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold">{{ $appt->patient->full_name }}</div>
                        <div class="text-muted small">
                            Dr. {{ $appt->doctor->user->name }} · {{ $appt->appointment_date->format('h:i A') }}
                        </div>
                        <div class="text-muted small">{{ $appt->reason }}</div>
                    </div>
                    <div class="ms-2">
                        <span class="badge badge-{{ $appt->status }}">{{ ucfirst(str_replace('_',' ',$appt->status)) }}</span>
                    </div>
                    @if($appt->isScheduled() && !$appt->visitQueue)
                    <form action="{{ route('appointments.check-in', $appt) }}" method="POST" class="ms-2">
                        @csrf
                        <button class="btn btn-sm btn-outline-success">Check-in</button>
                    </form>
                    @endif
                </div>
                @empty
                <div class="text-center py-4 text-muted">
                    <i class="bi bi-calendar-x fs-3 d-block mb-2"></i>No appointments today
                </div>
                @endforelse
            </div>
        </div>
    </div>

    {{-- Waiting Queue + Upcoming --}}
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-header py-3">
                <span><i class="bi bi-list-ol me-2 text-purple" style="color:#6f42c1"></i>Waiting Queue</span>
            </div>
            <div class="card-body p-0">
                @forelse($waitingQueue as $q)
                <div class="px-3 py-2 border-bottom d-flex align-items-center">
                    <div class="queue-number text-primary me-3" style="font-size:1.6rem; min-width:45px;">
                        {{ $q->queue_number }}
                    </div>
                    <div>
                        <div class="fw-semibold small">{{ $q->appointment->patient->full_name }}</div>
                        <div class="text-muted" style="font-size:.75rem;">Dr. {{ $q->appointment->doctor->user->name }}</div>
                    </div>
                </div>
                @empty
                <div class="text-center py-3 text-muted small">No one waiting</div>
                @endforelse
                @if($waitingQueue->count() > 0)
                <div class="p-2 text-center">
                    <a href="{{ route('queue.index') }}" class="btn btn-sm btn-outline-primary w-100">Manage Queue</a>
                </div>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="card-header py-3">
                <span><i class="bi bi-clock-history me-2 text-warning"></i>Upcoming</span>
            </div>
            <div class="card-body p-0">
                @forelse($upcomingAppointments as $appt)
                <div class="px-3 py-2 border-bottom">
                    <div class="fw-semibold small">{{ $appt->patient->full_name }}</div>
                    <div class="text-muted" style="font-size:.75rem;">
                        Dr. {{ $appt->doctor->user->name }} · {{ $appt->appointment_date->format('M d, h:i A') }}
                    </div>
                </div>
                @empty
                <div class="text-center py-3 text-muted small">No upcoming appointments</div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
