<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login – Clinic Visiting System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1a2540 0%, #0f6fcd 100%);
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        .login-card {
            width: 420px;
            border-radius: 16px;
            border: none;
            box-shadow: 0 20px 60px rgba(0,0,0,.3);
        }
        .login-header {
            background: linear-gradient(135deg, #1a2540, #0f6fcd);
            color: #fff;
            border-radius: 16px 16px 0 0;
            padding: 2.5rem 2rem 2rem;
            text-align: center;
        }
        .login-header h4 { font-weight: 700; margin-bottom: .25rem; }
        .login-header p { opacity: .8; font-size: .9rem; }
        .login-body { padding: 2rem; }
        .btn-login { background: #0f6fcd; border: none; padding: .75rem; font-weight: 600; }
        .btn-login:hover { background: #0a5aab; }
    </style>
</head>
<body>
<div class="card login-card">
    <div class="login-header">
        <i class="bi bi-hospital fs-1 mb-2 d-block"></i>
        <h4>Clinic Visiting System</h4>
        <p>Sign in to your account</p>
    </div>
    <div class="login-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle me-1"></i>
                {{ $errors->first() }}
            </div>
        @endif

        <form action="/login" method="POST">
            @csrf
            <div class="mb-3">
                <label class="form-label fw-semibold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control" value="{{ old('email') }}" placeholder="admin@clinic.local" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" name="remember" id="remember">
                <label class="form-check-label" for="remember">Remember me</label>
            </div>
            <button type="submit" class="btn btn-primary btn-login w-100 text-white">
                <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
            </button>
        </form>

        <div class="mt-4 p-3 bg-light rounded small text-muted">
            <strong>Demo credentials:</strong><br>
            Email: <code>admin@clinic.local</code><br>
            Password: <code>password</code>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
