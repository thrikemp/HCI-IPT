@extends('layouts.app')
@section('title', 'Visit Queue')
@section('page-title', 'Visit Queue')

@section('content')
<div class="row g-3">
    {{-- Queue Display --}}
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list-ol me-2 text-primary"></i>Today's Queue</span>
                <small class="text-muted">{{ now()->format('F d, Y') }}</small>
            </div>
            <div class="card-body p-0">
                @forelse($queues as $q)
                <div class="d-flex align-items-center px-3 py-3 border-bottom
                    {{ $q->status === 'in_progress' ? 'bg-light' : '' }}">
                    {{-- Queue Number --}}
                    <div class="me-3 text-center" style="min-width:55px;">
                        <div class="queue-number {{ $q->status === 'in_progress' ? 'text-primary' : 'text-secondary' }}">
                            {{ $q->queue_number }}
                        </div>
                        @if($q->status === 'in_progress')
                            <small class="text-primary fw-bold" style="font-size:.65rem;">IN ROOM</small>
                        @endif
                    </div>

                    {{-- Patient Info --}}
                    <div class="flex-grow-1">
                        <div class="fw-semibold">{{ $q->appointment->patient->full_name }}</div>
                        <div class="text-muted small">
                            Dr. {{ $q->appointment->doctor->user->name }}
                            · {{ $q->appointment->reason }}
                        </div>
                        <div class="text-muted" style="font-size:.72rem;">
                            Check-in: {{ $q->check_in_time ?? '—' }}
                            @if($q->called_time) · Called: {{ $q->called_time }} @endif
                            @if($q->done_time) · Done: {{ $q->done_time }} @endif
                        </div>
                    </div>

                    {{-- Status Badge --}}
                    <div class="mx-3">
                        <span class="badge badge-{{ $q->status }}">{{ ucfirst(str_replace('_',' ',$q->status)) }}</span>
                    </div>

                    {{-- Actions --}}
                    <div class="d-flex gap-1">
                        @if($q->status === 'waiting')
                            <form action="{{ route('queue.skip', $q) }}" method="POST">
                                @csrf @method('PATCH')
                                <button class="btn btn-sm btn-outline-warning" title="Skip">
                                    <i class="bi bi-skip-forward"></i>
                                </button>
                            </form>
                        @elseif($q->status === 'in_progress')
                            <form action="{{ route('queue.done', $q) }}" method="POST">
                                @csrf @method('PATCH')
                                <button class="btn btn-sm btn-success">
                                    <i class="bi bi-check-lg me-1"></i>Done
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
                @empty
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                    No patients in queue today
                </div>
                @endforelse
            </div>
        </div>
    </div>

    {{-- Doctor Call Panel --}}
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header py-3 fw-semibold">
                <i class="bi bi-megaphone me-2 text-success"></i>Call Next Patient
            </div>
            <div class="card-body">
                @forelse($doctors as $doctor)
                <div class="d-flex align-items-center justify-content-between mb-3 p-3 border rounded">
                    <div>
                        <div class="fw-semibold small">Dr. {{ $doctor->user->name }}</div>
                        <div class="text-muted" style="font-size:.75rem;">{{ $doctor->specialization }}</div>
                    </div>
                    <form action="{{ route('queue.call-next', $doctor) }}" method="POST">
                        @csrf
                        <button class="btn btn-sm btn-success">
                            <i class="bi bi-bell me-1"></i>Call
                        </button>
                    </form>
                </div>
                @empty
                <div class="text-muted small">No available doctors.</div>
                @endforelse
            </div>
        </div>

        {{-- Legend --}}
        <div class="card mt-3">
            <div class="card-body">
                <div class="small fw-semibold mb-2">Queue Legend</div>
                <div class="d-flex flex-column gap-1">
                    <span class="badge badge-waiting">Waiting – in queue</span>
                    <span class="badge badge-in_progress">In Progress – being seen</span>
                    <span class="badge badge-completed">Done – visit complete</span>
                    <span class="badge badge-cancelled">Skipped</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Auto-refresh queue every 30 seconds
setTimeout(() => location.reload(), 30000);
</script>
@endpush
