<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Clinic Visiting System')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 250px;
            --primary: #0f6fcd;
            --sidebar-bg: #1a2540;
            --sidebar-text: #c8d3e8;
            --sidebar-active: #0f6fcd;
        }
        body { background: #f0f4f8; font-family: 'Segoe UI', sans-serif; }
        .sidebar {
            width: var(--sidebar-width);
            min-height: 100vh;
            background: var(--sidebar-bg);
            position: fixed;
            top: 0; left: 0;
            display: flex; flex-direction: column;
            z-index: 1000;
        }
        .sidebar-brand {
            padding: 1.5rem 1.25rem;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .sidebar-brand h5 { color: #fff; font-weight: 700; margin: 0; font-size: 1rem; }
        .sidebar-brand small { color: var(--sidebar-text); font-size: .75rem; }
        .sidebar-nav { flex: 1; padding: 1rem 0; }
        .nav-section { padding: .5rem 1.25rem .25rem; font-size: .7rem; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,.35); }
        .sidebar .nav-link {
            color: var(--sidebar-text);
            padding: .55rem 1.25rem;
            display: flex; align-items: center; gap: .75rem;
            font-size: .875rem;
            border-left: 3px solid transparent;
            transition: all .15s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: #fff;
            background: rgba(255,255,255,.06);
            border-left-color: var(--sidebar-active);
        }
        .sidebar .nav-link i { width: 18px; text-align: center; font-size: 1rem; }
        .main-content { margin-left: var(--sidebar-width); min-height: 100vh; }
        .topbar {
            background: #fff;
            border-bottom: 1px solid #e2e8f0;
            padding: .75rem 1.5rem;
            display: flex; align-items: center; justify-content: space-between;
            position: sticky; top: 0; z-index: 100;
        }
        .page-content { padding: 1.75rem; }
        .card { border: none; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,.07); }
        .card-header { background: #fff; border-bottom: 1px solid #f0f0f0; font-weight: 600; }
        .badge-waiting   { background: #fff3cd; color: #856404; }
        .badge-in_progress { background: #cfe2ff; color: #084298; }
        .badge-scheduled { background: #d1ecf1; color: #0c5460; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
        .badge-no_show   { background: #e2e3e5; color: #383d41; }
        .stat-card { border-radius: 12px; padding: 1.25rem 1.5rem; color: #fff; }
        .queue-number { font-size: 2rem; font-weight: 800; line-height: 1; }
    </style>
    @stack('styles')
</head>
<body>

<div class="sidebar">
    <div class="sidebar-brand">
        <h5><i class="bi bi-hospital me-2"></i>ClinicMS</h5>
        <small>Visiting Management</small>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section">Main</div>
        <a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <i class="bi bi-grid"></i> Dashboard
        </a>
        <a href="{{ route('queue.index') }}" class="nav-link {{ request()->routeIs('queue.*') ? 'active' : '' }}">
            <i class="bi bi-list-ol"></i> Visit Queue
        </a>

        <div class="nav-section mt-2">Records</div>
        <a href="{{ route('appointments.index') }}" class="nav-link {{ request()->routeIs('appointments.*') ? 'active' : '' }}">
            <i class="bi bi-calendar-check"></i> Appointments
        </a>
        <a href="{{ route('patients.index') }}" class="nav-link {{ request()->routeIs('patients.*') ? 'active' : '' }}">
            <i class="bi bi-people"></i> Patients
        </a>
        <a href="{{ route('doctors.index') }}" class="nav-link {{ request()->routeIs('doctors.*') ? 'active' : '' }}">
            <i class="bi bi-person-badge"></i> Doctors
        </a>
    </nav>
    <div style="padding: 1rem 1.25rem; border-top: 1px solid rgba(255,255,255,.08);">
        <div style="color: var(--sidebar-text); font-size: .8rem; margin-bottom: .5rem;">
            <i class="bi bi-person-circle me-1"></i> {{ auth()->user()->name }}
            <span class="badge bg-secondary ms-1" style="font-size:.65rem">{{ auth()->user()->role }}</span>
        </div>
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button class="btn btn-sm btn-outline-secondary w-100" style="color:var(--sidebar-text);border-color:rgba(255,255,255,.2);">
                <i class="bi bi-box-arrow-left me-1"></i>Logout
            </button>
        </form>
    </div>
</div>

<div class="main-content">
    <div class="topbar">
        <div>
            <h6 class="mb-0 fw-semibold text-secondary">@yield('page-title', 'Dashboard')</h6>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="text-muted small"><i class="bi bi-clock me-1"></i>{{ now()->format('D, M d Y') }}</span>
        </div>
    </div>

    <div class="page-content">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>{{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('info'))
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>{{ session('info') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>
