@extends('layouts.app')
@section('title', 'Doctor Profile')
@section('page-title', 'Doctor Profile')

@section('content')
<div class="row g-3">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body text-center py-4">
                <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                     style="width:72px;height:72px;font-size:1.8rem;">
                    {{ strtoupper(substr($doctor->user->name,0,2)) }}
                </div>
                <h5 class="fw-bold mb-0">Dr. {{ $doctor->user->name }}</h5>
                <div class="text-muted small mb-1">{{ $doctor->specialization }}</div>
                <span class="badge {{ $doctor->is_available ? 'bg-success' : 'bg-secondary' }} mb-3">
                    {{ $doctor->is_available ? 'Available' : 'Unavailable' }}
                </span>
                <form action="{{ route('doctors.toggle-availability', $doctor) }}" method="POST" class="mb-2">
                    @csrf @method('PATCH')
                    <button class="btn btn-sm {{ $doctor->is_available ? 'btn-outline-warning' : 'btn-outline-success' }} w-100">
                        {{ $doctor->is_available ? 'Set Unavailable' : 'Set Available' }}
                    </button>
                </form>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><small class="text-muted d-block">License</small>{{ $doctor->license_number }}</li>
                <li class="list-group-item"><small class="text-muted d-block">Email</small>{{ $doctor->user->email }}</li>
                @if($doctor->phone)
                <li class="list-group-item"><small class="text-muted d-block">Phone</small>{{ $doctor->phone }}</li>
                @endif
                @if($doctor->bio)
                <li class="list-group-item"><small class="text-muted d-block">Bio</small>{{ $doctor->bio }}</li>
                @endif
            </ul>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header py-3 fw-semibold">
                <i class="bi bi-calendar-check me-2 text-primary"></i>Today's Appointments
            </div>
            <div class="card-body p-0">
                @forelse($todayAppointments as $appt)
                <div class="d-flex align-items-center px-3 py-2 border-bottom">
                    <div class="flex-grow-1">
                        <div class="fw-semibold small">{{ $appt->patient->full_name }}</div>
                        <div class="text-muted small">{{ $appt->appointment_date->format('h:i A') }} · {{ $appt->reason }}</div>
                    </div>
                    <span class="badge badge-{{ $appt->status }}">{{ ucfirst(str_replace('_',' ',$appt->status)) }}</span>
                </div>
                @empty
                <div class="text-center text-muted py-4">No appointments today.</div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
