@extends('layouts.app')
@section('title', 'Add Doctor')
@section('page-title', 'Add Doctor')

@section('content')
<div class="row">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header py-3"><i class="bi bi-person-badge me-2 text-primary"></i>Doctor Information</div>
            <div class="card-body">
                <form action="{{ route('doctors.store') }}" method="POST">
                    @csrf
                    <h6 class="text-muted mb-3">Account</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Full Name *</label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                   value="{{ old('name') }}" required>
                            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email *</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email') }}" required>
                            @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Password *</label>
                            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" required>
                            @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Confirm Password *</label>
                            <input type="password" name="password_confirmation" class="form-control" required>
                        </div>
                    </div>

                    <h6 class="text-muted mb-3">Professional Details</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Specialization *</label>
                            <input type="text" name="specialization" class="form-control @error('specialization') is-invalid @enderror"
                                   value="{{ old('specialization') }}" placeholder="e.g. General Medicine, Pediatrics" required>
                            @error('specialization')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">License Number *</label>
                            <input type="text" name="license_number" class="form-control @error('license_number') is-invalid @enderror"
                                   value="{{ old('license_number') }}" required>
                            @error('license_number')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Phone</label>
                            <input type="text" name="phone" class="form-control" value="{{ old('phone') }}">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Bio</label>
                            <textarea name="bio" class="form-control" rows="3" placeholder="Brief professional biography…">{{ old('bio') }}</textarea>
                        </div>
                    </div>

                    <div class="mt-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Add Doctor</button>
                        <a href="{{ route('doctors.index') }}" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
