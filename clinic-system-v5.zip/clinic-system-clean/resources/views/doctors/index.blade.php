@extends('layouts.app')
@section('title', 'Doctors')
@section('page-title', 'Doctors')

@section('content')
<div class="d-flex justify-content-end mb-3">
    <a href="{{ route('doctors.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Add Doctor
    </a>
</div>

<div class="row g-3">
    @forelse($doctors as $doctor)
    <div class="col-md-6 col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-start justify-content-between mb-3">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                         style="width:50px;height:50px;font-size:1.2rem;flex-shrink:0;">
                        {{ strtoupper(substr($doctor->user->name,0,2)) }}
                    </div>
                    <span class="badge {{ $doctor->is_available ? 'bg-success' : 'bg-secondary' }}">
                        {{ $doctor->is_available ? 'Available' : 'Unavailable' }}
                    </span>
                </div>
                <h6 class="fw-bold mb-0">Dr. {{ $doctor->user->name }}</h6>
                <div class="text-muted small mb-2">{{ $doctor->specialization }}</div>
                <div class="text-muted small mb-1"><i class="bi bi-card-text me-1"></i>License: {{ $doctor->license_number }}</div>
                @if($doctor->phone)
                <div class="text-muted small mb-1"><i class="bi bi-telephone me-1"></i>{{ $doctor->phone }}</div>
                @endif
                @if($doctor->bio)
                <div class="text-muted small mt-2">{{ Str::limit($doctor->bio, 80) }}</div>
                @endif
            </div>
            <div class="card-footer bg-white d-flex gap-2">
                <a href="{{ route('doctors.show', $doctor) }}" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-eye me-1"></i>View
                </a>
                <form action="{{ route('doctors.toggle-availability', $doctor) }}" method="POST">
                    @csrf @method('PATCH')
                    <button class="btn btn-sm {{ $doctor->is_available ? 'btn-outline-warning' : 'btn-outline-success' }}">
                        <i class="bi bi-toggle-{{ $doctor->is_available ? 'on' : 'off' }} me-1"></i>
                        {{ $doctor->is_available ? 'Set Unavailable' : 'Set Available' }}
                    </button>
                </form>
            </div>
        </div>
    </div>
    @empty
    <div class="col-12 text-center text-muted py-5">No doctors registered yet.</div>
    @endforelse
</div>
@endsection
