@echo off
echo ==========================================
echo   Clinic Visiting System - Setup Script
echo ==========================================

echo.
echo ^>^> Installing Composer dependencies...
composer install --no-interaction --prefer-dist

echo.
echo ^>^> Copying .env file...
if not exist .env (
    copy .env.example .env
)

echo.
echo ^>^> Generating application key...
php artisan key:generate

echo.
echo ^>^> Creating SQLite database...
if not exist database mkdir database
type nul > database\clinic.sqlite

echo.
echo ^>^> Running migrations and seeding...
php artisan migrate --seed --force

echo.
echo ==========================================
echo   Setup complete!
echo   Run: php artisan serve
echo   Open: http://localhost:8000
echo   Login: admin@clinic.local / password
echo ==========================================
pause
