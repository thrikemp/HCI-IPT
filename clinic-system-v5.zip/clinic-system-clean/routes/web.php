<?php

use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\QueueController;
use Illuminate\Support\Facades\Route;

// Auth
Route::get('/login', [AuthController::class, 'showLogin'])->name('login')->middleware('guest');
Route::post('/login', [AuthController::class, 'login'])->middleware('guest');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Protected routes
Route::middleware('auth')->group(function () {

    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Patients
    Route::resource('patients', PatientController::class);

    // Doctors
    Route::resource('doctors', DoctorController::class)->only(['index', 'create', 'store', 'show']);
    Route::patch('/doctors/{doctor}/toggle-availability', [DoctorController::class, 'toggleAvailability'])
        ->name('doctors.toggle-availability');

    // Appointments
    Route::resource('appointments', AppointmentController::class)->except(['destroy']);
    Route::patch('/appointments/{appointment}/cancel', [AppointmentController::class, 'cancel'])
        ->name('appointments.cancel');
    Route::post('/appointments/{appointment}/check-in', [AppointmentController::class, 'checkIn'])
        ->name('appointments.check-in');

    // Queue
    Route::get('/queue', [QueueController::class, 'index'])->name('queue.index');
    Route::post('/queue/call-next/{doctor}', [QueueController::class, 'callNext'])->name('queue.call-next');
    Route::patch('/queue/{queue}/done', [QueueController::class, 'markDone'])->name('queue.done');
    Route::patch('/queue/{queue}/skip', [QueueController::class, 'skip'])->name('queue.skip');
});
