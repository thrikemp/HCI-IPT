#!/bin/bash
set -e

echo "=========================================="
echo "  Clinic Visiting System – Setup Script"
echo "=========================================="

# 1. Install dependencies
echo ""
echo ">> Installing Composer dependencies..."
composer install --no-interaction --prefer-dist

# 2. Copy .env
if [ ! -f .env ]; then
    echo ">> Creating .env file..."
    cp .env.example .env
fi

# 3. Generate app key
echo ">> Generating application key..."
php artisan key:generate

# 4. Create SQLite database
echo ">> Creating SQLite database..."
mkdir -p database
touch database/clinic.sqlite

# 5. Run migrations + seed
echo ">> Running migrations and seeding..."
php artisan migrate --seed --force

# 6. Set storage permissions
echo ">> Setting storage permissions..."
chmod -R 775 storage bootstrap/cache 2>/dev/null || true

echo ""
echo "=========================================="
echo "  Setup complete!"
echo "  Run: php artisan serve"
echo "  Open: http://localhost:8000"
echo "  Login: admin@clinic.local / password"
echo "=========================================="
