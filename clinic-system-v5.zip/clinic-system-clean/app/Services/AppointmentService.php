<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\VisitQueue;
use Illuminate\Support\Facades\DB;

class AppointmentService
{
    public function create(array $data): Appointment
    {
        return DB::transaction(function () use ($data) {
            return Appointment::create($data);
        });
    }

    public function update(Appointment $appointment, array $data): Appointment
    {
        $appointment->update($data);
        return $appointment->fresh();
    }

    public function cancel(Appointment $appointment): Appointment
    {
        $appointment->update(['status' => 'cancelled']);

        if ($appointment->visitQueue) {
            $appointment->visitQueue->update(['status' => 'skipped']);
        }

        return $appointment->fresh();
    }

    public function checkIn(Appointment $appointment): VisitQueue
    {
        return DB::transaction(function () use ($appointment) {
            $appointment->update(['status' => 'scheduled']);

            return VisitQueue::create([
                'appointment_id' => $appointment->id,
                'queue_number'   => VisitQueue::nextQueueNumber(),
                'status'         => 'waiting',
                'check_in_time'  => now()->format('H:i:s'),
            ]);
        });
    }

    public function callNext(int $doctorId): ?VisitQueue
    {
        return VisitQueue::whereHas('appointment', function ($q) use ($doctorId) {
            $q->where('doctor_id', $doctorId)->whereDate('appointment_date', today());
        })
        ->where('status', 'waiting')
        ->orderBy('queue_number')
        ->first();
    }

    public function markInProgress(VisitQueue $queue): VisitQueue
    {
        $queue->update([
            'status'      => 'in_progress',
            'called_time' => now()->format('H:i:s'),
        ]);
        return $queue;
    }

    public function markDone(VisitQueue $queue): VisitQueue
    {
        DB::transaction(function () use ($queue) {
            $queue->update([
                'status'    => 'done',
                'done_time' => now()->format('H:i:s'),
            ]);
            $queue->appointment->update(['status' => 'completed']);
        });
        return $queue->fresh();
    }
}
