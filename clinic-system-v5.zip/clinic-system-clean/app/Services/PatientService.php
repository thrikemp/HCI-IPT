<?php

namespace App\Services;

use App\Models\Patient;

class PatientService
{
    public function create(array $data): Patient
    {
        return Patient::create($data);
    }

    public function update(Patient $patient, array $data): Patient
    {
        $patient->update($data);
        return $patient->fresh();
    }

    public function delete(Patient $patient): bool
    {
        return $patient->delete();
    }

    public function search(string $query)
    {
        return Patient::where('first_name', 'like', "%{$query}%")
            ->orWhere('last_name', 'like', "%{$query}%")
            ->orWhere('phone', 'like', "%{$query}%")
            ->orWhere('email', 'like', "%{$query}%")
            ->orderBy('last_name')
            ->get();
    }
}
