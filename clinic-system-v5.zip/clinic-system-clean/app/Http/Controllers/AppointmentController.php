<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreAppointmentRequest;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Services\AppointmentService;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    public function __construct(private AppointmentService $appointmentService) {}

    public function index(Request $request)
    {
        $status = $request->get('status');
        $date   = $request->get('date');

        $appointments = Appointment::with(['patient', 'doctor.user'])
            ->when($status, fn($q) => $q->where('status', $status))
            ->when($date, fn($q) => $q->whereDate('appointment_date', $date))
            ->orderByDesc('appointment_date')
            ->paginate(15);

        return view('appointments.index', compact('appointments', 'status', 'date'));
    }

    public function create(Request $request)
    {
        $patients = Patient::orderBy('last_name')->get();
        $doctors  = Doctor::with('user')->where('is_available', true)->get();
        $selectedPatient = $request->get('patient_id')
            ? Patient::find($request->get('patient_id'))
            : null;

        return view('appointments.create', compact('patients', 'doctors', 'selectedPatient'));
    }

    public function store(StoreAppointmentRequest $request)
    {
        $this->appointmentService->create($request->validated());

        return redirect()->route('appointments.index')
            ->with('success', 'Appointment scheduled successfully.');
    }

    public function show(Appointment $appointment)
    {
        $appointment->load(['patient', 'doctor.user', 'visitQueue']);
        return view('appointments.show', compact('appointment'));
    }

    public function edit(Appointment $appointment)
    {
        $patients = Patient::orderBy('last_name')->get();
        $doctors  = Doctor::with('user')->where('is_available', true)->get();
        return view('appointments.edit', compact('appointment', 'patients', 'doctors'));
    }

    public function update(StoreAppointmentRequest $request, Appointment $appointment)
    {
        $this->appointmentService->update($appointment, $request->validated());

        return redirect()->route('appointments.show', $appointment)
            ->with('success', 'Appointment updated successfully.');
    }

    public function cancel(Appointment $appointment)
    {
        $this->appointmentService->cancel($appointment);

        return back()->with('success', 'Appointment cancelled.');
    }

    public function checkIn(Appointment $appointment)
    {
        if ($appointment->visitQueue) {
            return back()->with('error', 'Patient already checked in.');
        }

        $this->appointmentService->checkIn($appointment);

        return back()->with('success', "Patient checked in. Queue #{$appointment->visitQueue->queue_number}");
    }
}
