<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class DoctorController extends Controller
{
    public function index()
    {
        $doctors = Doctor::with('user')->paginate(15);
        return view('doctors.index', compact('doctors'));
    }

    public function create()
    {
        return view('doctors.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'           => 'required|string|max:100',
            'email'          => 'required|email|unique:users,email',
            'password'       => 'required|min:8|confirmed',
            'specialization' => 'required|string|max:100',
            'license_number' => 'required|string|unique:doctors,license_number',
            'phone'          => 'nullable|string|max:20',
            'bio'            => 'nullable|string',
        ]);

        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
            'role'     => 'doctor',
        ]);

        Doctor::create([
            'user_id'        => $user->id,
            'specialization' => $request->specialization,
            'license_number' => $request->license_number,
            'phone'          => $request->phone,
            'bio'            => $request->bio,
            'is_available'   => true,
        ]);

        return redirect()->route('doctors.index')
            ->with('success', 'Doctor added successfully.');
    }

    public function show(Doctor $doctor)
    {
        $doctor->load(['user', 'appointments.patient']);
        $todayAppointments = $doctor->appointments()
            ->with('patient')
            ->today()
            ->get();

        return view('doctors.show', compact('doctor', 'todayAppointments'));
    }

    public function toggleAvailability(Doctor $doctor)
    {
        $doctor->update(['is_available' => !$doctor->is_available]);
        return back()->with('success', 'Availability updated.');
    }
}
