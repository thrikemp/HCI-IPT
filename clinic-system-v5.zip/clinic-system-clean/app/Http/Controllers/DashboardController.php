<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\VisitQueue;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_patients'        => Patient::count(),
            'total_doctors'         => Doctor::count(),
            'today_appointments'    => Appointment::today()->count(),
            'waiting_queue'         => VisitQueue::where('status', 'waiting')->whereDate('created_at', today())->count(),
        ];

        $todayAppointments = Appointment::with(['patient', 'doctor.user', 'visitQueue'])
            ->today()
            ->orderBy('appointment_date')
            ->get();

        $waitingQueue = VisitQueue::with(['appointment.patient', 'appointment.doctor.user'])
            ->where('status', 'waiting')
            ->whereDate('created_at', today())
            ->orderBy('queue_number')
            ->get();

        $upcomingAppointments = Appointment::with(['patient', 'doctor.user'])
            ->upcoming()
            ->orderBy('appointment_date')
            ->limit(5)
            ->get();

        return view('dashboard.index', compact(
            'stats',
            'todayAppointments',
            'waitingQueue',
            'upcomingAppointments'
        ));
    }
}
