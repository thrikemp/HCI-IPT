<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\VisitQueue;
use App\Services\AppointmentService;

class QueueController extends Controller
{
    public function __construct(private AppointmentService $appointmentService) {}

    public function index()
    {
        $queues = VisitQueue::with(['appointment.patient', 'appointment.doctor.user'])
            ->whereDate('created_at', today())
            ->orderBy('queue_number')
            ->get();

        $doctors = Doctor::with('user')->where('is_available', true)->get();

        return view('queue.index', compact('queues', 'doctors'));
    }

    public function callNext(Doctor $doctor)
    {
        $queue = $this->appointmentService->callNext($doctor->id);

        if (!$queue) {
            return back()->with('info', 'No patients waiting in queue.');
        }

        $this->appointmentService->markInProgress($queue);

        return back()->with('success', "Queue #{$queue->queue_number} – {$queue->appointment->patient->full_name} called.");
    }

    public function markDone(VisitQueue $queue)
    {
        $this->appointmentService->markDone($queue);
        return back()->with('success', 'Visit marked as completed.');
    }

    public function skip(VisitQueue $queue)
    {
        $queue->update(['status' => 'skipped']);
        return back()->with('success', 'Queue entry skipped.');
    }
}
