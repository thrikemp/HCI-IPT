<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VisitQueue extends Model
{
    use HasFactory;

    protected $fillable = [
        'appointment_id',
        'queue_number',
        'status',
        'check_in_time',
        'called_time',
        'done_time',
    ];

    public function appointment()
    {
        return $this->belongsTo(Appointment::class);
    }

    public static function nextQueueNumber(): int
    {
        $lastQueue = self::whereDate('created_at', today())->max('queue_number');
        return ($lastQueue ?? 0) + 1;
    }
}
